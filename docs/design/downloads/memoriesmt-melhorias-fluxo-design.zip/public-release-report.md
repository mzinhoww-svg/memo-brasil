# Public production release verification

URL: https://newmemocuiaba.vercel.app

Expected source SHA supplied by release owner after productionReady: `b776b642e69aa7a4dbb14d8fa36ad23929487fe0`. The browser does not independently attest the deployment commit; actual loaded script hashes are recorded below.

Checked at 2026-11-08T05:36:53.500Z. Read-only Chromium verification through the inherited cloud HTTPS proxy.

Result: **PASS** (0 failed checks).

| Viewport | Route | HTTP | Horizontal overflow | Page errors |
| --- | --- | --- | --- | --- |
| desktop | `/` | 200 | none | 0 |
| desktop | `/precos` | 200 | none | 0 |
| desktop | `/ajuda` | 200 | none | 0 |
| desktop | `/criar` | 200 | none | 0 |
| desktop | `/entrar` | 200 | none | 0 |
| mobile | `/` | 200 | none | 0 |
| mobile | `/precos` | 200 | none | 0 |
| mobile | `/ajuda` | 200 | none | 0 |
| mobile | `/criar` | 200 | none | 0 |
| mobile | `/entrar` | 200 | none | 0 |

Visible Preços links to /precos were checked on home, prices, and help in both viewports.

- desktop: Até 10 · GrátisGrátis · 10 fotos por pessoa; Até 30 · R$ 29,00Festa · 24 fotos por pessoa; Até 100 · R$ 89,00Celebração · 24 fotos por pessoa; Até 250 · R$ 189,00Casamento · 36 fotos por pessoaRecomendado; Até 500 · R$ 349,00Grande · fotos sem limite. Teste/R$1 offer absent; 1 successful public catalog response(s).
- mobile: Até 10 · GrátisGrátis · 10 fotos por pessoa; Até 30 · R$ 29,00Festa · 24 fotos por pessoa; Até 100 · R$ 89,00Celebração · 24 fotos por pessoa; Até 250 · R$ 189,00Casamento · 36 fotos por pessoaRecomendado; Até 500 · R$ 349,00Grande · fotos sem limite. Teste/R$1 offer absent; 1 successful public catalog response(s).

- desktop: 10 actual script responses captured; checkout route present. Matching assets: `/_next/static/immutable/chunks/2f4zp_-get5yx.js` (SHA-256 `60d18e6ff56d5a1a8e34dbcbfd2808d8c2c77ff692ac5438c2cf033b74bb1767`)
- mobile: 10 actual script responses captured; checkout route present. Matching assets: `/_next/static/immutable/chunks/2f4zp_-get5yx.js` (SHA-256 `60d18e6ff56d5a1a8e34dbcbfd2808d8c2c77ff692ac5438c2cf033b74bb1767`)

Mobile screenshots: [home](public-release-home-mobile.png), [prices](public-release-precos-mobile.png). Raw observations: [JSON](public-release-results.json).

Both mobile screenshots were visually inspected: navigation, primary actions, plan amounts, and public help copy are legible within the viewport. The initial Chromium launch was blocked by the command sandbox before navigation (`setsockopt: Operation not permitted`); the same script then completed with exit code 0 using the approved outer executor and inherited HTTPS proxy.

Scope: public home, prices, help, event creation entry, and login entry only. No Google login, identities, events, checkout submissions, reservations, charges, or refunds were created. Non-read-only network requests other than public catalog RPCs were blocked. This check does not establish real financial homologation.

No failed checks in this bounded public verification.
